package OpenInteract::Handler::Fruit;

use strict;

$OpenInteract::Handler::Fruit::VERSION = '0.01';
$OpenInteract::Handler::Fruit::author = 'lemburg@aixonix.de';

my $DEBUG  = 1;
my $TMPL_CLASS = 'OpenInteract::Template::Toolkit'; # temporary until context stuff works

sub handler {
  my $class = shift;
  my $p     = shift;
  my $R = OpenInteract::Request->instance;
  my $fruits = $R->fruit->fetch_group( { 'order' => 'name' } ); 
  my $params = { fruits_in_store => $fruits };
  my $tmpl_name = 'fruit-display';
  return $TMPL_CLASS->handler( {}, $params, { db => $tmpl_name, package => 'fruit' } );
}

1;
