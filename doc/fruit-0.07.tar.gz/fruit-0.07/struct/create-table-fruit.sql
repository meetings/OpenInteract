create table fruit (
    id %%INCREMENT%%,
    name varchar(255),
    taste varchar(255),
    price varchar(255),
    primary key (id)
)
    
