CREATE TABLE sys_error (
 error_id      char(12) not null,
 code          varchar2(10) not null,
 type          varchar2(20) null,
 user_msg      varchar2(500) null,
 system_msg    varchar2(500) null,
 package       varchar2(40) not null,
 filename      varchar2(60) not null,
 line          smallint not null,
 action        varchar2(25) null,
 user_id       %%USERID_TYPE%% null,
 session_id    varchar2(32) null,
 browser       varchar2(75) null,
 referer       varchar2(150) null,
 error_time    date null,
 url           varchar2(150) null,
 notes         varchar2(500) null,
 primary key   ( error_id )
)

