CREATE TABLE object_keys (
  object_key   char(32) not null,
  class        varchar(75) not null,
  object_id    varchar(255) not null,
  primary key  ( object_key ),
  unique       ( class, object_id )
)