CREATE TABLE sys_security (
 sid            %%INCREMENT%%,
 class          varchar(75) not null,
 object_id      varchar(150) default '0',
 scope          char(1) not null,
 scope_id       varchar(50) default 'world',
 security_level char(1) not null,
 primary key    ( sid ),
 unique         ( object_id, class, scope, scope_id )
)
