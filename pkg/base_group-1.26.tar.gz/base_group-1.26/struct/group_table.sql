CREATE TABLE sys_group (
 group_id      %%INCREMENT%%,
 name          varchar(30) not null,
 notes         text null,
 primary key   ( group_id )
)
