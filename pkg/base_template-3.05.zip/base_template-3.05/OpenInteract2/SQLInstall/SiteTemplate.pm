package OpenInteract2::SQLInstall::SiteTemplate;

# $Id: SiteTemplate.pm,v 1.1 2003/03/25 14:23:44 lachoy Exp $

use strict;
use base qw( OpenInteract2::SQLInstall );

sub get_security_file {
    return 'install_security.dat';
}

1;
