CREATE TABLE news (
 news_id       int not null,
 posted_on     date not null, 
 posted_by     %%USERID_TYPE%% not null,
 title         varchar2(75) null,
 news_item     clob null,
 section       varchar2(20) default 'Public',
 active        char(3) default 'yes',
 expires_on    date null,
 active_on     date null,
 primary key   ( news_id )
)
