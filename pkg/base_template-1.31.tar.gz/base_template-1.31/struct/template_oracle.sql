CREATE TABLE template (
 template_id   int not null,
 name          varchar2(40) not null,
 title         varchar2(100) null,
 description   varchar2(500) null,
 template      clob not null,
 script        clob null,
 package       varchar2(40) not null,
 last_update   int null,
 primary key   ( template_id ),
 unique        ( name, package )
)