CREATE TABLE template (
 template_id   %%INCREMENT%%,
 name          varchar(40) not null,
 title         varchar(100),
 description   blob,
 template      blob not null,
 script        blob,
 package       varchar(40) not null,
 last_update   int,
 primary key   ( template_id ),
 unique        ( name, package )
)