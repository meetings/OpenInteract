CREATE TABLE full_text_index (
 object_key    char(32) not null,
 term          varchar2(30) not null,
 occur         int not null,
 primary key   ( term, object_key )
)