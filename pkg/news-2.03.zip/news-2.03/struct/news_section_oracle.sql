CREATE TABLE news_section (
  news_section_id   int not null,
  section           varchar2(20) not null,
  primary key( news_section_id )
)