package OpenInteract::SQLInstall::ObjectActivity;

# $Id: ObjectActivity.pm,v 1.2 2001/10/18 03:59:07 lachoy Exp $

use strict;
use vars qw( %HANDLERS );

@OpenInteract::SQLInstall::ObjectActivity::ISA = qw( OpenInteract::SQLInstall );

my %files = (
 tables   => [ 'object_track.sql' ],
 data     => [],
 security => [ 'install_security.dat' ],

);

%HANDLERS = (
 create_structure => { '_default_' => [ 'create_structure', 
                                        { table_file_list => $files{tables} } ] },
 install_data     => { '_default_' => [ 'install_data',
                                        { data_file_list => $files{data} } ] },
 install_security => { '_default_' => [ 'install_data',
                                        { data_file_list => $files{security} } ] },
);

1;
