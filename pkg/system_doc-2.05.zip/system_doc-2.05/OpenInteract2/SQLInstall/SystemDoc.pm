package OpenInteract2::SQLInstall::SystemDoc;

# $Id: SystemDoc.pm,v 1.2 2003/06/08 16:16:31 lachoy Exp $

use strict;
use base qw( OpenInteract2::SQLInstall );

sub get_security_file {
    return 'install_security.dat';
}

1;
