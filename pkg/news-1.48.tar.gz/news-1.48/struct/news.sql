CREATE TABLE news (
 news_id       %%INCREMENT%%,
 posted_on     datetime not null, 
 posted_by     %%USERID_TYPE%% not null,
 title         varchar(75),
 news_item     text,
 image_src     varchar(255) null,
 image_url     varchar(255) null,
 image_align   varchar(5) null,
 section       varchar(20) default 'Public',
 active        char(3) default 'yes',
 expires_on    datetime,
 active_on     datetime,
 primary key   ( news_id )
)
