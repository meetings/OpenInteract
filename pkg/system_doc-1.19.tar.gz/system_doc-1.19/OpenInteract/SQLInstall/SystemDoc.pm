package OpenInteract::SQLInstall::SystemDoc;

# $Id: SystemDoc.pm,v 1.1.1.1 2001/02/02 06:20:42 lachoy Exp $

# Do installation of SQL for this package

use strict;
use vars qw( %HANDLERS );

@OpenInteract::SQLInstall::SystemDoc::ISA = qw( OpenInteract::SQLInstall );

my %files = (
  security => [ 'install_security.dat' ],
);

%HANDLERS = (
  install_security => { '_default_' => [ 'install_data',
                                         { data_file_list => $files{security} } ] },
);

1;

__END__

=pod

=head1 NAME

OpenInteract::SQLInstall::SystemDoc - SQL installer for the system_doc package

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 BUGS 

=head1 TO DO

=head1 SEE ALSO

=head1 COPYRIGHT

Copyright (c) 2001 intes.net, inc.. All rights reserved.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 AUTHORS

Chris Winters <chris@cwinters.com>

=cut
