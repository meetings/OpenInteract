CREATE TABLE sys_error (
 error_id      char(12) not null,
 code          varchar(10) not null,
 type          varchar(20) null,
 user_msg      text null,
 system_msg    text null,
 package       varchar(40) not null,
 filename      varchar(60) not null,
 line          smallint not null,
 action        varchar(25) null,
 user_id       %%INCREMENT_TYPE%% null,
 session_id    varchar(32) null,
 browser       varchar(75) null,
 referer       varchar(150) null,
 error_time    datetime null,
 notes         text null,
 primary key   ( error_id )
)

