package OpenInteract::SQLInstall::SiteTemplate;

# $Id: SiteTemplate.pm,v 1.6 2002/08/25 00:03:26 lachoy Exp $

use strict;
use vars qw( %HANDLERS );
use base qw( OpenInteract::SQLInstall );

my %files = (
    security      => [ 'install_security.dat' ],
);

%HANDLERS = (
    install_security => { '_default_' => [ 'install_data',
                                           { data_file_list => $files{security} } ] },
);

1;
