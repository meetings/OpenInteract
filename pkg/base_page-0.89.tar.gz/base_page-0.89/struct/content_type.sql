CREATE TABLE content_type (
  content_type_id   %%INCREMENT%%,
  mime_type         varchar(40) not null,
  extensions        varchar(20) not null,
  description       varchar(100) null,
  image_source      varchar(50) null,
  PRIMARY KEY       ( content_type_id ),
  UNIQUE            ( mime_type )
)