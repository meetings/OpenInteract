CREATE TABLE sys_group_user (
 group_id      %%INCREMENT_TYPE%% not null,
 user_id       %%INCREMENT_TYPE%% not null,
 primary key   ( group_id, user_id )
)
