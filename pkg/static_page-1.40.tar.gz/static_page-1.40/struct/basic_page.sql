CREATE TABLE basic_page (
 location       varchar(150) not null,
 directory      varchar(150) null,
 title          varchar(250) null,
 author         varchar(200) null,
 keywords       varchar(75) null,
 notes          text null,
 active_on      datetime null,
 expires_on     datetime null,
 boxes          varchar(75) null,
 main_template  varchar(40) null,
 is_file        char(3) default 'no',
 primary key    ( location )
)
