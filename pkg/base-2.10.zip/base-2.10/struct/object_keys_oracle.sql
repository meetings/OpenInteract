CREATE TABLE object_keys (
  object_key   char(32) not null,
  class        varchar2(75) not null,
  object_id    varchar2(255) not null,
  primary key  ( object_key ),
  unique       ( class, object_id )
)