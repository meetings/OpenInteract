CREATE TABLE page_content (
 location      varchar2(150) not null,
 content       clob null,
 primary key   ( location )
)