CREATE TABLE template (
 template_id   %%INCREMENT%%,
 name          varchar(40) not null,
 title         varchar(100) null,
 description   text null,
 template      text not null,
 script        text null,
 package       varchar(40) null,
 primary key   ( template_id ),
 unique        ( name, package )
)