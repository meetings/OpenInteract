CREATE TABLE sys_security (
 sid           %%INCREMENT%%,
 class         varchar(75) not null,
 oid           varchar(150) not null default '0',
 scope         char(1) not null,
 scope_id      varchar(16) null default 'world',
 level         char(1) not null,
 primary key   ( sid ),
 unique        ( oid, class, scope, scope_id )
)
