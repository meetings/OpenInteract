package OpenInteract2::SQLInstall::Lookup;

# $Id: Lookup.pm,v 1.1 2003/03/26 13:09:03 lachoy Exp $

use strict;
use base qw( OpenInteract2::SQLInstall );

sub get_security_file {
    return 'install_security.dat';
}

1;
