package OpenInteract::SQLInstall::SystemDoc;

# $Id: SystemDoc.pm,v 1.2 2001/10/29 03:37:58 lachoy Exp $

# Do installation of SQL for this package

use strict;
use vars qw( %HANDLERS );

@OpenInteract::SQLInstall::SystemDoc::ISA = qw( OpenInteract::SQLInstall );

my %files = (
  data     => [ 'page.dat' ],
  security => [ 'install_security.dat' ],
);

%HANDLERS = (
  install_data     => { '_default_' => [ 'install_data',
                                         { data_file_list => $files{data} } ] },
  install_security => { '_default_' => [ 'install_data',
                                         { data_file_list => $files{security} } ] },
);

1;
