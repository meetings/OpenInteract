package OpenInteract::SQLInstall::Error;

# $Id: Error.pm,v 1.3 2002/01/02 02:43:54 lachoy Exp $

# Do installation of SQL for this package

use strict;
use vars qw( %HANDLERS );

@OpenInteract::SQLInstall::Error::ISA = qw( OpenInteract::SQLInstall );

my %files = (
    tables   => [ 'error.sql' ],
    data     => [ 'install_theme_prop.dat' ],
    security => [ 'install_security.dat' ],
);

%HANDLERS = (
    create_structure => { '_default_' => [ 'create_structure', 
                                           { table_file_list => $files{tables} } ] },
    install_data     => { '_default_' => [ 'install_data',
                                           { data_file_list => $files{data} } ] },
    install_security => { '_default_' => [ 'install_data',
                                           { data_file_list => $files{security} } ] },
);

1;

__END__

=pod

=head1 NAME

OpenInteract::SQLInstall::Error - SQL installer for the error package

=head1 SYNOPSIS

=head1 DESCRIPTION

=head1 BUGS 

=head1 TO DO

=head1 SEE ALSO

=head1 COPYRIGHT

Copyright (c) 2001-2002 intes.net, inc.. All rights reserved.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 AUTHORS

Chris Winters <chris@cwinters.com>

=cut
