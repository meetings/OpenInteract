CREATE TABLE basic_page (
 location       varchar(150) not null,
 title          varchar(250) null,
 author         varchar(200) null,
 pagetext       text null,
 script         text null,
 keywords       varchar(75) null,
 notes          text null,
 active_on      datetime null,
 expires_on     datetime null,
 boxes          varchar(75) null,
 main_template  varchar(40) null,
 primary key    ( location )
)