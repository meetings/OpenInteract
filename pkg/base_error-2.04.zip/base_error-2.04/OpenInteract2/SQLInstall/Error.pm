package OpenInteract2::SQLInstall::Error;

# $Id: Error.pm,v 1.1 2003/03/21 13:10:27 lachoy Exp $

use strict;
use base qw( OpenInteract2::SQLInstall );

sub get_structure_set {
    return 'error_object';
}

# We don't care what the $set is since there's only one

sub get_structure_file {
    my ( $class, $set, $type ) = @_;
    return 'sys_error_oracle.sql'    if ( $type eq 'Oracle' );
    return 'sys_error_interbase.sql' if ( $type eq 'InterBase' );
    return 'sys_error.sql';
}

sub get_security_file {
    return 'install_security.dat';
}

1;
