CREATE TABLE sys_error (
 error_id      char(12) not null,
 category      varchar2(50) not null,
 err_message   varchar2(500) null,
 loc_class     varchar2(60) null,
 loc_line      smallint null,
 user_id       %%USERID_TYPE%% null,
 session_id    varchar2(32) null,
 browser       varchar2(75) null,
 referer       varchar2(150) null,
 error_time    date null,
 url           varchar2(150) null,
 primary key   ( error_id )
)

