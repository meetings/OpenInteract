CREATE TABLE sys_error (
 error_id      char(12) not null,
 category      varchar(50) not null,
 err_message   blob,
 loc_class     varchar(60),
 loc_line      int,
 user_id       %%USERID_TYPE%%,
 session_id    varchar(32),
 browser       varchar(75),
 referer       varchar(150),
 error_time    timestamp,
 url           varchar(150),
 primary key   ( error_id )
)

