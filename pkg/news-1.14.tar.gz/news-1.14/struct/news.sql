CREATE TABLE news (
 news_id       %%INCREMENT%%,
 posted_on     datetime not null, 
 posted_by     int not null,
 title         varchar(75) null,
 news_item     text null,
 active        char(3) default 'yes',
 expires_on    datetime null,
 active_on     datetime null,
 primary key   ( news_id )
)
