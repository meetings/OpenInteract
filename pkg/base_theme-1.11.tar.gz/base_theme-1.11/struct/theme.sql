CREATE TABLE theme (
 theme_id      %%INCREMENT%%,
 title         varchar(50) not null,
 description   text null,
 parent        int not null,
 credit        varchar(200) null,
 primary key   ( theme_id )
)
