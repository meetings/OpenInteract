CREATE TABLE object_track (
 class         varchar(50) not null,
 oid           varchar(16) not null,
 action        varchar(10) not null default 'create',
 action_by     int not null,
 action_on     datetime not null,
 notes         text null,
 primary key   ( class, oid, action, action_by, action_on )
)