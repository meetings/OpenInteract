CREATE TABLE sys_group_user (
 group_id      int not null,
 user_id       int not null,
 primary key   ( group_id, user_id )
)
