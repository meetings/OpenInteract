CREATE TABLE page (
 location         varchar(150) not null,
 directory        varchar(150) null,
 title            varchar(250) null,
 author           varchar(200) null,
 keywords         varchar(75) null,
 boxes            varchar(75) null,
 template_parse   char(3) default 'yes',
 main_template    varchar(40) null,
 active_on        datetime null,
 expires_on       datetime null,
 is_active        char(3) default 'no',
 content_location varchar(150) null,
 storage          varchar(10) default 'database',
 mime_type        varchar(30) null,
 size             int default 0,
 notes            text null,
 primary key      ( location )
)
