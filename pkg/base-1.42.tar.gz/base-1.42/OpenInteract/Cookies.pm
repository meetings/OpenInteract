package OpenInteract::Cookies;

# $Id: Cookies.pm,v 1.4 2001/05/18 12:21:29 lachoy Exp $

use strict;
use Data::Dumper qw( Dumper );

sub error_message {
  return <<ERR
Please change your website configuration file (conf/server.perl)
to use either 'OpenInteract::Cookies::CGI' (uses CGI::Cookie, which 
is generally available with Perl) or 'OpenInteract::Cookies::Apache'
(uses Apache::Cookie which is an optional module available when you
install Apache::Request a.k.a. libapreq).
ERR
}

sub parse         { die error_message(); }
sub bake          { die error_message(); }
sub create_cookie { die error_message(); }

1;

__END__

=pod

=head1 NAME

OpenInteract::Cookies - Deprecated

=head1 DESCRIPTION

This module is deprecated and no longer used at all. Please use either
L<OpenInteract::Cookies::CGI> or L<OpenInteract::Cookies::Apache>.

=cut
