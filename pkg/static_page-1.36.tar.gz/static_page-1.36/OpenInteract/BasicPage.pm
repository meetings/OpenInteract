package OpenInteract::BasicPage;

# $Id: BasicPage.pm,v 1.1 2001/06/07 16:57:24 lachoy Exp $

use strict;

$OpenInteract::BasicPage::VERSION = sprintf("%d.%02d", q$Revision: 1.1 $ =~ /(\d+)\.(\d+)/);

# Just replace the generated 'url' method with one that just uses the
# location. This won't work if you do not have the BasicPage handler
# answering all 'unknown' requests.

sub object_description {
  my ( $self ) = @_;
  my $info = $self->SUPER::object_description();
  $info->{url} = $self->{location};
  return $info;
}

1;
