package OpenInteract::SQLInstall::FullText;

# $Id: FullText.pm,v 1.3 2002/04/13 17:28:11 lachoy Exp $

use strict;
use vars qw( %HANDLERS );

@OpenInteract::SQLInstall::FullText::ISA = qw( OpenInteract::SQLInstall );

my %files = (
  tables        => [ 'full_text_index.sql' ],
  tables_oracle => [ 'full_text_index_oracle.sql' ],
);

%HANDLERS = (
  create_structure => { '_default_' => [ 'create_structure',
                                         { table_file_list => $files{tables} } ],
                        'Oracle'    => [ 'create_structure',
                                         { table_file_list => $files{tables_oracle} } ], },
);

1;
