CREATE TABLE page_content (
 location      varchar(150) not null,
 content       blob,
 primary key   ( location )
)