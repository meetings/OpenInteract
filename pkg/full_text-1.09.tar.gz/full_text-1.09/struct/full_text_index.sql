CREATE TABLE full_text_index (
 term          varchar(30) not null,
 ft_oid        varchar(125) not null,
 occur         int not null,
 primary key   ( term, ft_oid )
)