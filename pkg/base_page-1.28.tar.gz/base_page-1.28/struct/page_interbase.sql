CREATE TABLE page (
 location         varchar(150) not null,
 directory        varchar(150),
 title            varchar(250),
 author           varchar(200),
 keywords         varchar(75),
 boxes            varchar(75),
 template_parse   char(3) default 'yes',
 main_template    varchar(40),
 active_on        timestamp,
 expires_on       timestamp,
 is_active        char(3) default 'no',
 content_location varchar(150),
 storage          varchar(10) default 'database',
 mime_type        varchar(50),
 page_size        int default 0,
 notes            blob,
 primary key      ( location )
)
