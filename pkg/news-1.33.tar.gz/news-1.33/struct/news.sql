CREATE TABLE news (
 news_id       %%INCREMENT%%,
 posted_on     datetime not null, 
 posted_by     %%USERID_TYPE%% not null,
 title         varchar(75) null,
 news_item     text null,
 section       varchar(20) default 'Public',
 active        char(3) default 'yes',
 expires_on    datetime null,
 active_on     datetime null,
 primary key   ( news_id )
)
