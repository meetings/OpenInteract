CREATE TABLE object_track (
 class         varchar(50) not null,
 object_id     varchar(150) not null,
 action        varchar(10) default 'create',
 action_by     %%INCREMENT_TYPE%% not null,
 action_on     datetime not null,
 notes         text null,
 primary key   ( class, object_id, action, action_by, action_on )
)