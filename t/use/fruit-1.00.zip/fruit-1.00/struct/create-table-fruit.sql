create table fruit (
    id           %%INCREMENT%%,
    name         varchar(100),
    taste        varchar(100),
    price        numeric(7,2),
    primary key  (id)
)
    
